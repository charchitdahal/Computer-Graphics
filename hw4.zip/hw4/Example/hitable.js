class hit_record {
    get t() { return this.t_val; };
    set t(val){ this.t_val = val; };

    // Your code goes here:
    // Follow the example above to write getter() and setter() for p and normal.

    get p() { return this.p_val; };
    set p(pos) { this.p_val = pos };

    get normal() { return this.n; };
    set normal(normal) { this.n = normal};

}




