
class ray{
    // Your code goes here:
    
     ray(){ 

     }

     ray(a, b){
         A = a;
         B = b;
     }

    origin(){
        return A;
    } 

    direction() {
         return B;
     }

    point_at_paramenter(t){
        return A + t*B;
    }    
    
}